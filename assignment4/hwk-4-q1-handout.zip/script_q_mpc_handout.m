clear all; close all; clc;

addpath(genpath('./fcns'));

% define system matrices and parameters

dt = 0.1;                                   % sampling time

A = [1, dt;
     0, 1];

B = [0; dt];

C = [1, 0];

[nz, nu] = size(B);                         % system size
[ny,  ~] = size(C);                         % output size

G = 0.025*eye(nz);                          % process noise
K = 0.05*eye(ny);                           % measurement noise

z0 = [4;0];                                 % initial condition

% define MPC parameters

n_pred = 10;                                % prediction horizon
n_sim  = 100*n_pred;                        % simulation horizon
t_space = linspace(0,dt*n_sim,n_sim+1);     % simulation time grid
yd = 10*cos(2*pi*t_space/50);               % desired trajectory

Q = eye(nz);                                % penalty on state variable
R = 0.1*eye(nu);                            % penalty on control variable

Qy = eye(ny);                               % penalty on output variable

% define constraint matrices
lbz = [-5;-inf];                            % lower bound on state
ubz = [5; inf];                             % upper bound on state

lbu = [-1];                                 % lower bound on control
ubu = [1];                                  % upper bound on control

lb = [kron(ones(n_pred,1), lbz); kron(ones(n_pred, 1), lbu)];
ub = [kron(ones(n_pred,1), ubz); kron(ones(n_pred, 1), ubu)];

Omega = sparse(getOmega(A,n_pred,'lti'));
Psi   = sparse(getPsi(A,B,n_pred,'lti'));
Aeq = [-eye(n_pred*nz) Psi];
beq = Omega*z0;

% define cost function
H = blkdiag(kron(eye(n_pred),Q), kron(eye(n_pred),R)); % quadratic cost
f = zeros((nz+nu)*n_pred,1);                           % linear cost

% simulate MPC 

z_array = zeros(nz,n_sim);
z_array(:,1) = z0;
y_array = zeros(ny,n_sim);
y_array(:,1) = C*z0 + sqrtm(K)*randn([ny,1]);
u_array = zeros(nu,n_sim);

% optimizer options
opts.Display = 'off';

for kk = 1:n_sim

    fprintf('Iteration %i\n',kk)
    % solve MPC
    x = quadprog(H,f,[],[],Aeq,beq,lb,ub,[],opts);
    z_opt = reshape(x(1:nz*n_pred),nz,n_pred);
    u_opt = reshape(x(nz*n_pred+1:end),nu,n_pred);
    u_array(:,kk) = u_opt(:,1);

    % propagate and measure
    z_array(:,kk+1) = A*z_array(:,kk) + B*u_array(:,kk) + sqrtm(G)*randn([nz,1]);
    y_array(:,kk+1) = C*z_array(:,kk) + sqrtm(K)*randn([ny,1]);

    % update initial condition
    beq = Omega*z_array(:,kk+1);

end

h1 = figure;
plot(t_space, y_array)